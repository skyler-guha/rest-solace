"""Module for storing custom exception classes.
"""

class CustomException(Exception):
    """Raised when a thing happens"""
