References:

https://netmetic.wordpress.com/2019/04/18/setting-up-a-rest-delivery-point-for-soap-endpoints/
https://docs.solace.com/API/REST/Using-REST.htm
https://docs.solace.com/API/RESTMessagingPrtl/Solace-REST-Message-Encoding.htm#_Ref399926122
https://docs.solace.com/API/RESTMessagingPrtl/Solace-REST-Message-Encoding.htm
https://solace.community/discussion/1637/can-i-implemengt-rest-request-reply-mechanism-using-rest-delivery-points

